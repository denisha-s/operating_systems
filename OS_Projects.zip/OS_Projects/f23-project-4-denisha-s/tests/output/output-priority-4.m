SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:      388.85
    Avg. turnaround time:   3141.08

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:     4139.60
    Avg. turnaround time:   7040.80

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           7761
Total service time:           2134
Total I/O time:               1835
Total dispatch time:          5604
Total idle time:                23

CPU utilization:            99.70%
CPU efficiency:             27.50%

