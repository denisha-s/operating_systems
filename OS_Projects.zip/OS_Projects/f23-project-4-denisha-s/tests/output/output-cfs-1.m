SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  3
    Avg. response time:       98.00
    Avg. turnaround time:   1067.00

NORMAL THREADS:
    Total Count:                  4
    Avg. response time:      137.25
    Avg. turnaround time:   1605.75

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1827
Total service time:            628
Total I/O time:                517
Total dispatch time:          1078
Total idle time:               121

CPU utilization:            93.38%
CPU efficiency:             34.37%

