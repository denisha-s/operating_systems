SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:      593.69
    Avg. turnaround time:   5855.31

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:      670.60
    Avg. turnaround time:   6501.70

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           8210
Total service time:           2134
Total I/O time:               1835
Total dispatch time:          6066
Total idle time:                10

CPU utilization:            99.88%
CPU efficiency:             25.99%
