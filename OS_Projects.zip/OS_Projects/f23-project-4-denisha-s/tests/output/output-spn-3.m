SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:      457.00
    Avg. turnaround time:   4241.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:     1260.88
    Avg. turnaround time:   2347.38

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      363.50
    Avg. turnaround time:   2731.75

Total elapsed time:           4323
Total service time:           1127
Total I/O time:                891
Total dispatch time:          3196
Total idle time:                 0

CPU utilization:           100.00%
CPU efficiency:             26.07%

