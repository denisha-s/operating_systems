SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  2
    Avg. response time:      218.50
    Avg. turnaround time:    546.00

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       47.00
    Avg. turnaround time:    295.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:            667
Total service time:            223
Total I/O time:                191
Total dispatch time:           362
Total idle time:                82

CPU utilization:            87.71%
CPU efficiency:             33.43%

