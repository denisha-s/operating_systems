SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:       59.00
    Avg. turnaround time:    617.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       36.00
    Avg. turnaround time:    355.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:            697
Total service time:            170
Total I/O time:                185
Total dispatch time:           372
Total idle time:               155

CPU utilization:            77.76%
CPU efficiency:             24.39%
