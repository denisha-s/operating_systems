SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  3
    Avg. response time:       31.33
    Avg. turnaround time:   1441.33

NORMAL THREADS:
    Total Count:                  4
    Avg. response time:       56.25
    Avg. turnaround time:   1126.50

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1828
Total service time:            628
Total I/O time:                517
Total dispatch time:          1158
Total idle time:                42

CPU utilization:            97.70%
CPU efficiency:             34.35%

