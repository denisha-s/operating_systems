SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  2
    Avg. response time:       88.50
    Avg. turnaround time:    983.00

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       47.00
    Avg. turnaround time:    844.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1080
Total service time:            223
Total I/O time:                191
Total dispatch time:           788
Total idle time:                69

CPU utilization:            93.61%
CPU efficiency:             20.65%

