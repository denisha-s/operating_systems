SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:      625.00
    Avg. turnaround time:   3853.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:      372.25
    Avg. turnaround time:   2644.62

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      277.25
    Avg. turnaround time:   2770.00

Total elapsed time:           4261
Total service time:           1127
Total I/O time:                891
Total dispatch time:          3109
Total idle time:                25

CPU utilization:            99.41%
CPU efficiency:             26.45%
