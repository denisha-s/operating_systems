SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  2
    Avg. response time:       96.00
    Avg. turnaround time:   1223.00

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       47.00
    Avg. turnaround time:   1010.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1399
Total service time:            223
Total I/O time:                191
Total dispatch time:          1096
Total idle time:                80

CPU utilization:            94.28%
CPU efficiency:             15.94%
