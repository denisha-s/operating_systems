SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:      503.46
    Avg. turnaround time:  25157.46

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:      564.10
    Avg. turnaround time:  28021.10

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:          34611
Total service time:           2134
Total I/O time:               1835
Total dispatch time:         32412
Total idle time:                65

CPU utilization:            99.81%
CPU efficiency:              6.17%
