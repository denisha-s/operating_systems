SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  3
    Avg. response time:       52.33
    Avg. turnaround time:    499.67

NORMAL THREADS:
    Total Count:                  4
    Avg. response time:      592.75
    Avg. turnaround time:    873.50

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1126
Total service time:            628
Total I/O time:                517
Total dispatch time:           361
Total idle time:               137

CPU utilization:            87.83%
CPU efficiency:             55.77%

