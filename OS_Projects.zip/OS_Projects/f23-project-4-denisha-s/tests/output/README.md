The files in this directory are named as follows:
```
output-ALGORITHM[-TIME_SLICE]-INPUT_TEST_NO.MODE_FLAG
```

For example, if you run your simulation with these parameters,
```
./cpu-sim -v -a RR -s 6 tests/input/input-2
```

your simulation output should look like the contents of the following file:
```
tests/output/ouput-rr-s6-2.v
```

