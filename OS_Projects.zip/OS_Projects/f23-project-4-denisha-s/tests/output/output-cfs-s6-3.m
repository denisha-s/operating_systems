SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:      511.00
    Avg. turnaround time:   1649.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:      302.75
    Avg. turnaround time:   4848.25

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      227.00
    Avg. turnaround time:   8097.75

Total elapsed time:           8631
Total service time:           1127
Total I/O time:                891
Total dispatch time:          7438
Total idle time:                66

CPU utilization:            99.24%
CPU efficiency:             13.06%

