SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:      523.00
    Avg. turnaround time:   9766.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:      299.12
    Avg. turnaround time:   6580.50

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      223.50
    Avg. turnaround time:   6730.75

Total elapsed time:          10229
Total service time:           1127
Total I/O time:                891
Total dispatch time:          9043
Total idle time:                59

CPU utilization:            99.42%
CPU efficiency:             11.02%
