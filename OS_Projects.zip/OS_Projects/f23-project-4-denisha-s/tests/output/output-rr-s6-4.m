SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:      530.54
    Avg. turnaround time:  14513.62

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:      595.80
    Avg. turnaround time:  16419.50

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:          20202
Total service time:           2134
Total I/O time:               1835
Total dispatch time:         18003
Total idle time:                65

CPU utilization:            99.68%
CPU efficiency:             10.56%
