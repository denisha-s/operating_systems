SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  3
    Avg. response time:      111.00
    Avg. turnaround time:   1145.67

NORMAL THREADS:
    Total Count:                  4
    Avg. response time:      168.00
    Avg. turnaround time:    699.75

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1447
Total service time:            628
Total I/O time:                517
Total dispatch time:           777
Total idle time:                42

CPU utilization:            97.10%
CPU efficiency:             43.40%
