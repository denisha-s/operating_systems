SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  3
    Avg. response time:      101.00
    Avg. turnaround time:    883.67

NORMAL THREADS:
    Total Count:                  4
    Avg. response time:      145.25
    Avg. turnaround time:   1388.75

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1623
Total service time:            628
Total I/O time:                517
Total dispatch time:           864
Total idle time:               131

CPU utilization:            91.93%
CPU efficiency:             38.69%

