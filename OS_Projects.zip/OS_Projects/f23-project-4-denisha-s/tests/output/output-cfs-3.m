SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:      484.00
    Avg. turnaround time:   2097.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:      287.75
    Avg. turnaround time:   7634.25

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      217.25
    Avg. turnaround time:  12583.25

Total elapsed time:          13131
Total service time:           1127
Total I/O time:                891
Total dispatch time:         11938
Total idle time:                66

CPU utilization:            99.50%
CPU efficiency:              8.58%

