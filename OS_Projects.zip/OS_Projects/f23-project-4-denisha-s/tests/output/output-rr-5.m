SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:       57.00
    Avg. turnaround time:   2023.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       36.00
    Avg. turnaround time:   1594.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           2103
Total service time:            170
Total I/O time:                185
Total dispatch time:          1778
Total idle time:               155

CPU utilization:            92.63%
CPU efficiency:              8.08%
