SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:       55.00
    Avg. turnaround time:    968.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       36.00
    Avg. turnaround time:    747.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           1048
Total service time:            170
Total I/O time:                185
Total dispatch time:           732
Total idle time:               146

CPU utilization:            86.07%
CPU efficiency:             16.22%

