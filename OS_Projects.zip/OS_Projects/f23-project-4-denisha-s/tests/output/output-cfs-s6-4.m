SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:      526.77
    Avg. turnaround time:   8096.54

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:      582.60
    Avg. turnaround time:  17432.20

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:          18755
Total service time:           2134
Total I/O time:               1835
Total dispatch time:         16611
Total idle time:                10

CPU utilization:            99.95%
CPU efficiency:             11.38%

