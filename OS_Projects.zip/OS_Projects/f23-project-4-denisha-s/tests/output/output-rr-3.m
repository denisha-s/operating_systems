SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:      490.00
    Avg. turnaround time:  16602.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:      280.00
    Avg. turnaround time:  11342.50

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      216.25
    Avg. turnaround time:  12066.00

Total elapsed time:          17622
Total service time:           1127
Total I/O time:                891
Total dispatch time:         16436
Total idle time:                59

CPU utilization:            99.67%
CPU efficiency:              6.40%
