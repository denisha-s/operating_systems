SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  3
    Avg. response time:       85.00
    Avg. turnaround time:   2808.33

NORMAL THREADS:
    Total Count:                  4
    Avg. response time:      139.50
    Avg. turnaround time:   1579.50

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           3268
Total service time:            628
Total I/O time:                517
Total dispatch time:          2559
Total idle time:                81

CPU utilization:            97.52%
CPU efficiency:             19.22%
