SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

INTERACTIVE THREADS:
    Total Count:                  1
    Avg. response time:       64.00
    Avg. turnaround time:   5189.00

NORMAL THREADS:
    Total Count:                  8
    Avg. response time:      238.38
    Avg. turnaround time:   4218.00

BATCH THREADS:
    Total Count:                  4
    Avg. response time:      371.25
    Avg. turnaround time:   5021.25

Total elapsed time:           6164
Total service time:           1127
Total I/O time:                891
Total dispatch time:          4947
Total idle time:                90

CPU utilization:            98.54%
CPU efficiency:             18.28%

