SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                  2
    Avg. response time:       91.50
    Avg. turnaround time:   2128.00

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                  1
    Avg. response time:       47.00
    Avg. turnaround time:   1847.00

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           2351
Total service time:            223
Total I/O time:                191
Total dispatch time:          2048
Total idle time:                80

CPU utilization:            96.60%
CPU efficiency:              9.49%
