SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:     1887.85
    Avg. turnaround time:   5227.15

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:     1499.10
    Avg. turnaround time:   5410.20

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:           8181
Total service time:           2134
Total I/O time:               1835
Total dispatch time:          6003
Total idle time:                44

CPU utilization:            99.46%
CPU efficiency:             26.08%

