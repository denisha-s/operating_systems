SIMULATION COMPLETED!

SYSTEM THREADS:
    Total Count:                 13
    Avg. response time:      506.15
    Avg. turnaround time:  13857.69

INTERACTIVE THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

NORMAL THREADS:
    Total Count:                 10
    Avg. response time:      557.80
    Avg. turnaround time:  30647.40

BATCH THREADS:
    Total Count:                  0
    Avg. response time:        0.00
    Avg. turnaround time:      0.00

Total elapsed time:          32363
Total service time:           2134
Total I/O time:               1835
Total dispatch time:         30219
Total idle time:                10

CPU utilization:            99.97%
CPU efficiency:              6.59%

