#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
//functions so main can see them before declared
struct node;
void check(FILE *file, char* name);
void checkTwo(char* file1, char* file2);
void reverse(struct node * start);
void reverseFile(struct node * start, FILE *end);
struct node* linkedList(FILE *file, struct node *start);


//main run code
int main(int argc, char *argv[])
{
	//simple starting vars
	FILE* file;
	FILE* save;
	struct node *start = NULL;
	//run checks here
	if (argc == 2) {
		//check if file exists
		file = fopen(argv[1], "r");
		check(file, argv[1]);
		start = linkedList(file, start);
		reverse(start);
	}
	else if (argc == 3) {
		file = fopen(argv[1], "r");
		
		//check if file exists
		check(file, argv[1]);

		//check if both files are different
		checkTwo(argv[1], argv[2]);
		start = linkedList(file, start);
		save = fopen(argv[2], "w");

		reverseFile(start, save);
	}
	else {
		//return some error and exit
		fprintf(stderr, "usage: reverse <input> <output>\n");
		return 1;
		exit(1);
	}
	return 0;
}

struct node
{
	char *string;
	struct node *previous;
};

struct node* linkedList(FILE *file, struct node *start) {
	//make linked list
	//start node
	struct node* head = NULL;
	//read first line
	char* temp;
	size_t len = 0;
	
	//loop while line is not end of file
	
	while (true) {
		int lineCheck = getline(&temp, &len, file);
		//set memory
		if(lineCheck == -1){
			break;
		}
		start = malloc(sizeof(struct node));
		//make is so new node becomes head and points back to previous head
		start->string = (char*)malloc(len * sizeof(char));
		strncpy(start->string,temp, len);
		start->previous = head;
		//reset vars for next loop
		head = start;
		len = 0;
		free(temp);
	}
	free(temp);
	fclose(file);
return head;

}

void check(FILE *file, char *name ) {
	if (file == NULL) {
		fprintf(stderr, "error: cannot open file '%s'\n", name);
		exit(1);
	}
}

void checkTwo(char* file1, char* file2) {
	if (strcmp(file1, file2) == 0) {
		fprintf(stderr, "error: input and output file must differ\n");
		//return some error and exit
		exit(1);
	}
}


void reverse(struct node* start) {
	struct node *temp = NULL;
	while (start != NULL) {
		temp = start;
		fprintf(stdout, "%s", start->string);
		start = start -> previous;
		free(temp->string);
		free(temp);
	}
}

void reverseFile(struct node * start, FILE *end) {
	struct node *temp = NULL;
	while (start != NULL) {
		temp = start;
		fprintf(end, "%s", start->string);
		start = start -> previous;
		free(temp->string);
		free(temp);
	}
	fclose(end);
}