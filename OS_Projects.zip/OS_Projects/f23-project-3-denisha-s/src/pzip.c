#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pzip.h"

pthread_barrier_t barrier;
pthread_mutex_t mutex;
pthread_mutex_t charMute[26];

void *compress(void *voidThread);

struct counters {
	char currChar;
	int count;
	struct counters *next;
};

struct arguments {
	int threadNum;
	int n_threads;
	char *input_chars;
	int input_chars_size;
	struct zipped_char *zipped_chars;
	int *zipped_chars_count;
	int *char_frequency;
	int *freq_counts;
};



/**
 * pzip() - zip an array of characters in parallel
 *
 * Inputs:
 * @n_threads:		   The number of threads to use in pzip
 * @input_chars:		   The input characters (a-z) to be zipped
 * @input_chars_size:	   The number of characaters in the input file
 *
 * Outputs:
 * @zipped_chars:       The array of zipped_char structs
 * @zipped_chars_count:   The total count of inserted elements into the zippedChars array.
 * @char_frequency[26]: Total number of occurences
 *
 * NOTE: All outputs are already allocated. DO NOT MALLOC or REASSIGN THEM !!!
 *
 */
void pzip(int n_threads, char *input_chars, int input_chars_size,
	  struct zipped_char *zipped_chars, int *zipped_chars_count,
	  int *char_frequency)
{


	if (0 != pthread_barrier_init(&barrier, NULL, n_threads)) {
		fprintf(stderr, "error cannot make barrier\n");
		exit(1);
	}
	if (0 != pthread_mutex_init(&mutex, NULL)) {
		fprintf(stderr, "error cannot mutex 1\n");
		exit(1);
	}
	
	int i;
	for (i = 0; i < 26; i++) {
		if (0 != pthread_mutex_init(&charMute[i], NULL)) {
			fprintf(stderr, "error cannot make char mute\n");
			exit(1);
	}
	}
	
	pthread_t threads[n_threads];
	struct arguments *args[n_threads];
	int* freq_counts = (int*) malloc(n_threads * sizeof(int));

	for (i = 0; i < n_threads; i++) {
		args[i] = (struct arguments*) malloc(sizeof(struct arguments));
		args[i]->threadNum = i;
		args[i]->n_threads = n_threads;
		args[i]->zipped_chars = zipped_chars;
		args[i]->zipped_chars_count = zipped_chars_count;
		args[i]->char_frequency = char_frequency;
		args[i]->freq_counts = freq_counts;
		args[i]->input_chars = input_chars;
		args[i]->input_chars_size = input_chars_size;
		if (0 != pthread_create(&threads[i], NULL, compress,args[i])) {
			fprintf(stderr, "error cannot make thread\n");
			exit(1);
		}
	}

	for (i = 0; i < n_threads; i++) {
		void *status;
		if (0 != pthread_join(threads[i], &status)) {
			fprintf(stderr, "error cannot join threads\n");
			exit(1);
		}
		if (status != 0) {
			fprintf(stderr, "Error in thread\n");
			exit(1);
		}
		free(args[i]);
	}

	if (0 != pthread_barrier_destroy(&barrier)) {
		fprintf(stderr, "error cannot destory barrier\n");
		exit(1);
	}
	if (0 != pthread_mutex_destroy(&mutex)) {
		fprintf(stderr, "error cannot destory mutex\n");
		exit(1);
	}
	for (i = 0; i < 26; i++) {
		if (0 != pthread_mutex_destroy(&charMute[i])) {

	}
	}
	free(freq_counts);
}

void *compress(void *voidThread) {
		struct arguments* thread = (struct arguments*) voidThread;
		int charCount = thread->input_chars_size/thread->n_threads;
		
		struct counters* head = (struct counters*) malloc(sizeof(struct counters));
		struct counters* nextCount = head;
		nextCount->next = NULL;
		int i;
		char currChar;
		int countZip = 0;
		int total = 0;
		for (i = charCount*thread->threadNum; i < charCount*(thread->threadNum + 1); i++) {
			currChar = thread->input_chars[i];
			int count = 0;
			while (currChar == thread->input_chars[i+1]) {
				count++;
				i++;
				if (i >= charCount*(thread->threadNum + 1)-1) {
					break;
				}
			}
			count++;
			total += count;
			nextCount->currChar = currChar;
			nextCount->count = count;
			if (total == charCount) {
				nextCount->next = NULL;
			} else {
				nextCount->next = (struct counters*) malloc(sizeof(struct counters));
				nextCount = nextCount->next;
				nextCount->next = NULL;
			}


			countZip++;

		}

		thread->freq_counts[thread->threadNum] = countZip;
		pthread_barrier_wait(&barrier);
		pthread_mutex_lock(&mutex);
		(*thread->zipped_chars_count) += countZip;
		pthread_mutex_unlock(&mutex);
		int freqStart = 0;
		for (i = 0; i < thread->threadNum; i++) {
			freqStart = freqStart + thread->freq_counts[i];
		}


		int j = freqStart;
		while (true) {
			pthread_mutex_lock(&charMute[(int) head->currChar - 97]);
			thread->char_frequency[(int) head->currChar - 97] += head->count;
			pthread_mutex_unlock(&charMute[(int) head->currChar - 97]);
			thread->zipped_chars[j].character = head->currChar;
			thread->zipped_chars[j].occurence = head->count;

			struct counters* temp = head->next;
			free(head);
			head = temp;
			j++;
			if (head == NULL) {
				break;
			}
		}
		return 0;
	}
